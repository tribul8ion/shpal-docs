readme.txt - Information for IrfanView ZIP users


*** IMPORTANT INFOS !!! ***


1) Be sure, you unpack IrfanView into a folder with write permissions (required for the INI file).
By default: the INI file will be saved in the IrfanView folder, unless you redirect it 
with the "INI_Folder=" value (see FAQs).
----


2) Please start IrfanView and call (once) any of the dialogs:

- Properties (P), or
- File->Open (O), or
- File->Save As (S), or
- Batch (B)


to convert/set IrfanView INI file to UNICODE mode !


If the INI file is not converted to Unicode, some of the options (like filenames, paths or text options) 
may NOT be saved properly and the feature may not be working as expected.
----
